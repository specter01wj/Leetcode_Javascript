Similar to the problem [Power of Two](https://github.com/hanzichi/leetcode/tree/master/Algorithms/Power%20of%20Two) and [Power of Three](https://github.com/hanzichi/leetcode/tree/master/Algorithms/Power%20of%20Three). 

Use `Math.log`.