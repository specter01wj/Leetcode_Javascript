Use regular expression, it's easy.

Just remove the needless blanks, and make a reverse.