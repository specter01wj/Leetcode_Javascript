Notice: 

- the int32 range: -2^31 ~ 2^31-1
- this problem is a little puzzling, you should take overflow into consideration
- although it's really nothing to JavaScript
- you should also notice that 1 << 31 will overflow in JavaScript