I just solve it with using extra space.

Traverse the Linked List, mark the node which has been traversed (here use extra space).

It's alse strange that we cannot use window.xx in this code, it's quite strange.