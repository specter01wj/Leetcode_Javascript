It's the easiest `Binary Indexed Tree` problem.

If you are Chinese, I suggest you reading [this](http://www.cnblogs.com/zichi/p/4806998.html) and [this](http://www.cnblogs.com/zichi/p/4807072.html) to learn Binary Indexed Tree once written by me.

If you are not, I suggest you turning to Google for help.