The difficulty is how to find the loop, use an array to hash.

Notice that both numerator and denominator can be negative.

