Simple Recurrence Problem.

To get the ways you are climbing to Step 3, you can either climb from Step 2, or Step 1. So if you know the answer that you climb to Step 2 and 1, you can also know the answer to Step 3.