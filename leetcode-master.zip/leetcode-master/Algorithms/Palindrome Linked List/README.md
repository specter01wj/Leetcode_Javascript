> **Follow up:**
> 
> Could you do it in O(n) time and O(1) space?


I didn't, I use O(n) space ...