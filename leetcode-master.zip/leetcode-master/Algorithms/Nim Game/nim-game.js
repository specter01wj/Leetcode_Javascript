// Source : https://leetcode.com/problems/nim-game/
// Author : Han Zichi
// Date   : 2016-01-20

/**
 * @param {number} n
 * @return {boolean}
 */
var canWinNim = function(n) {
  return n % 4
};