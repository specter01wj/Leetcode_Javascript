Try to know the conversion rules, and it will be easy.

Similar problem [Excel Sheet Column Title](https://github.com/hanzichi/leetcode/tree/master/Algorithms/Excel%20Sheet%20Column%20Title).