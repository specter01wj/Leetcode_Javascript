An easy  dynamic programming problem.

`dp[i]` means the `ith` ugly number, and `dp[i]*2`, `dp[i]*3`, `dp[i]*5` are also ugly numbers.. think it over