JavaScript does not have Pointer like C++, but we can use `new` to simulate.

What's more? The string may contain `.`, so we should use depth first search to find the answer.