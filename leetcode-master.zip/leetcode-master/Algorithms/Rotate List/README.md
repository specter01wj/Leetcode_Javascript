I do it with the most stupid way, cut the list into some nodes, put them into an array, rearrange the array, at last make a new list ..

You can solve it with a better solution!