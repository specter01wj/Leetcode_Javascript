I just solve it with the most stupid way, get every node from the list, push them to an array, delete the one which shoud be deleted, make the items in the array with another list, that's the answer.

Notice that `splice` function will operate the original array, and return the deleted items with an array.