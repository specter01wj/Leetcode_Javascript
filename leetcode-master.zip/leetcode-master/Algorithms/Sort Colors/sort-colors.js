// Source : https://leetcode.com/problems/sort-colors/
// Author : Han Zichi
// Date   : 2015-08-10

/**
 * @param {number[]} nums
 * @return {void} Do not return anything, modify nums in-place instead.
 */

var sortColors = function(nums) {
  nums.sort();
};