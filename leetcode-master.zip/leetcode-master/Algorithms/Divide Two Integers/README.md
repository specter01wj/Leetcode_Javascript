I think it's designed for some language such as C, C++, because they have int overflow..

I do it with JavaScript, and I do not have these trouble.. Maybe I have misunderstood the real purpose of the provider of this problem.