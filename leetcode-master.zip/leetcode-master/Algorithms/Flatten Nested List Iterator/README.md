How to say, it's not a difficult problem, but a rather troublesome one.

You should always notice that `nestedList` is consist of instances of `NestedInteger` . And then you can flatten it with functions `getInteger` or `getList`. 

Use `shift` and `unshift` in javascript, it will be easier.