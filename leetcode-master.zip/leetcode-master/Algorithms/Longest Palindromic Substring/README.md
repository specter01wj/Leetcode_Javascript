If you are Chinese, I suggest you reading [this article](http://www.cnblogs.com/zichi/p/4753930.html) written by me.

If you are not, I suggest you learning the algorithm named `Manacher`.

Similar to [Shortest Palindrome](https://github.com/hanzichi/leetcode/tree/499881dc6bdea4625ff68caccb27c952e9236395/Algorithms/Shortest%20Palindrome)