Use breadth first search.

You cannot modify a string, so you should use a hash array.