If there is not any number in the array, we should obviously choose 1, 2, 4, 8, 16 ... such numbers can make up "big number" with the fewest numbers. 

And if there is no 1, we should certainly choose 1, after choosing, we can see what numbers we can make up, and choose another, until reaching the goal.