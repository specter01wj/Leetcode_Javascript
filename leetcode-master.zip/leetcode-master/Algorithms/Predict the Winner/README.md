It seems to be a nim game, but it's a dynamic programming problem instead!
