I use `O(n^2)` to solve it, there will be a better solution! 

Think it over using binary search.