It's like [Best Time to Buy and Sell Stock II](https://leetcode.com/problems/best-time-to-buy-and-sell-stock-ii/). Go to solve that problem and see the [explanation](https://github.com/hanzichi/leetcode/blob/master/Algorithms/Best%20Time%20to%20Buy%20and%20Sell%20Stock%20II/README.md) here firstly.

In this problem, we can define three array named `sell`, `buy`, and `rest`, everyday we can sell, buy, or rest, it's the DP problem as well.

Think it over.