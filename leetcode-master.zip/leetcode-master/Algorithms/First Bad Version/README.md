Easy `binary search` problem.

Remember not to use `~~` and `>>1` because the number is so large, use `Math.floor()` or `Math.ceil()` and `/` instead.