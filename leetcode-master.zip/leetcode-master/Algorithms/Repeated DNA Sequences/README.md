I solve it by a kind of `hash` (maybe a little hack), also using `Set`. I regard `ACGT` as `0123`.

I don't think it is a good solution. But the result is **You are here! 
Your runtime beats 100.00% of javascript submissions.**