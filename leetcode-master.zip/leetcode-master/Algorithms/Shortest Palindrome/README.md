If you are Chinese, I suggest you reading [this article](http://www.cnblogs.com/zichi/p/4753930.html) written by me.

If you are not, I suggest you learning the algorithm named `Manacher`.