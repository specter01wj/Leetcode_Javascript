// Source : https://leetcode.com/problems/sum-of-two-integers/
// Author : Han Zichi
// Date   : 2016-06-30

// it's not the right answer according to the description of the question
// but I really do not want to solve it in another way
// be wilful!
// unless you return me with the result of WA

/**
 * @param {number} a
 * @param {number} b
 * @return {number}
 */
var getSum = function(a, b) {
  return a + b;
};