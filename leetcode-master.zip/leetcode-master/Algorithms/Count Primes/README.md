Just see the **Hint** in the question.

It's a common way to get primes within a certain range.