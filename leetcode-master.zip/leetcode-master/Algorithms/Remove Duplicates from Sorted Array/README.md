Use `splice` to remove an item from an array.

To this problem, you should enum items from `nums.length-1` to `0` to make it easier.